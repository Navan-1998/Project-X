﻿//13. Write a program to print the sum of digits and to check the number is palindrome or not
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int num = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            int temp = num;
            int palsum = 0;
            int r;
            int paltemp = num;

            while (num>0)
            {
                r = num % 10;
                sum = sum + r;
                palsum = (palsum * 10) + r;
                num = num / 10;
            }
            if (paltemp==palsum)
            {
                Console.WriteLine($"Number is Palindrome");
            }
            else
            {
                Console.WriteLine($"Number is not palindrome");
            }
            Console.ReadKey(); 
        }
    }
}
