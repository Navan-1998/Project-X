﻿//20. Write a program to perform following operations in an array:

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment20
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of elements in Array");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] array = new int[n];

            Console.WriteLine("Enter the elements in Array");
            for (int i=0; i<n; i++)
            {
                Console.WriteLine($"Enter the element {i + 1} :");
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            while(true)
            {
                Console.WriteLine("Choose an operation:");
                Console.WriteLine("1.Insert");
                Console.WriteLine("2.Traverse");
                Console.WriteLine("3.Delete");
                Console.WriteLine("4.Search");
                Console.WriteLine("5.Update");
                Console.WriteLine("6.Reverse");
                Console.WriteLine("7.Sort");
                Console.WriteLine("8.Sum and Average");
                Console.WriteLine("9.Sum of odd and even");
                Console.WriteLine("10.Largest and Smallest");
                Console.WriteLine("11.Copy to another number");
                Console.WriteLine("12.Print Unique Number");
                Console.WriteLine("13.Most repeaed Number");
                Console.WriteLine("14.Count of duplicate Entries");
                Console.WriteLine("0.Exit");

                int options = Convert.ToInt32(Console.ReadLine());

                switch(options)
                {
                    case 1://inserting

                        Console.WriteLine("Enter the value");
                        int value = Convert.ToInt32(Console.ReadLine());

                        int[] newarray = new int[array.Length + 1];
                        for (int i=0; i<array.Length;i++)
                        {
                            newarray[i] = array[i];
                            newarray[array.Length-1] = value;

                            array = newarray;
                            Console.WriteLine("Element Inserted");

                        }
                        Console.WriteLine(newarray);
                        for (int i=0;i<array.Length;i++)
                        {
                            Console.WriteLine(newarray[i]);
                        }
                        break;
                    case 2://traversing
                        Console.WriteLine("Array Elements are:");
                        for (int i=0;i<array.Length;i++)
                        {
                            Console.WriteLine(array[i]);
                        }
                        break;
                    case 3://delete
                        newarray = new int[array.Length - 1];
                        for (int i=0;i<newarray.Length-1;i++)
                        {
                            newarray[i] = array[i];
                            Console.WriteLine(newarray[i]);
                        }
                        array = newarray;
                        Console.WriteLine("Element Deleted");
                        break;
                    case 4://search
                        Console.WriteLine("Enter Element to be searched");
                        int element = Convert.ToInt32(Console.ReadLine());
                        for (int i=0;i<array.Length;i++)
                        {
                            if (array[i] == element)
                            {
                                Console.WriteLine($"{element} is found at the {i} position");
                            }
                            else
                            {
                                Console.WriteLine($"{element} is not found");
                            }
                        }
                        break;

                    case 5://updatng
                        Console.WriteLine("Enter the Index Position be to updated:");
                        int indexposition = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Enter the Value to be updated");
                        int updateelement=Convert.ToInt32(Console.ReadLine());

                        for (int i = 0; i < array.Length;i++)
                        {
                            array[indexposition] = updateelement;
                            Console.WriteLine(array[i]);
                        }
                        Console.WriteLine("Array Updated");
                        for (int i = 0; i<array.Length; i++)
                        {
                            Console.WriteLine(array[i]);
                        }
                        break;

                    case 6://Reverse

                        int a = array.Length;

                        for (int i=0;i<a/2;i++)
                        {
                            int temp = array[i];
                            array[i] = array[a - i - 1];
                            array[a - i - 1] = temp;
                        }
                        Console.WriteLine("Array Reversed");
                        for (int i=0;i<a;i++)
                        {
                            Console.WriteLine(array[i]);
                        }
                        break;

                    case 7://sort
                        n = array.Length;
                        for (int i=0;i<n-1;i++)
                        {
                            for (int j=i+1;j<n;j++)
                            {
                                if (array[i]>array[j])
                                {
                                    int temp = array[i];
                                    array[i] = array[j];
                                    array[j] = temp;


                                }
                            }
                        }
                        Console.WriteLine("Array Sorted:");
                        for (int i=0;i<array.Length;i++)
                        {
                            Console.WriteLine(array[i]);
                        }
                        break;

                    case 8://sum and average
                        int sum = 0;
                        for (int i=0;i<array.Length;i++)
                        {
                            sum = sum + array[i];
                        }
                        double average = sum / array.Length;
                        Console.WriteLine($"Sum={sum} , average ={ average}");
                        break;

                    case 9://sum of odd and even 
                        int oddsum = 0;
                        int evensum = 0;
                        for (int i=0;i<array.Length;i++)
                        {
                            if (array[i]%2==0)
                            {
                                evensum = evensum + array[i];
                            }
                            else
                            {
                                oddsum= oddsum + array[i];
                            }
                        }
                        Console.WriteLine($"Even Sum is:{evensum}");
                        Console.WriteLine($"Odd Sum is:{oddsum}");
                        break;
                    case 10://largest and smallest
                        int largest =array[0];
                        int smallest=array[0];
                        for (int i=1;i<array.Length;i++)
                        {
                            if (array[i] > largest)
                                largest = array[i];

                            if (array[i] < smallest)
                                smallest = array[i];
                        }
                        Console.WriteLine($"Largest is:{largest}");
                        Console.WriteLine($"Largest is:{smallest}");
                        break;

                    case 11://array copied
                        int[] copyarray = new int[array.Length];
                        for (int i=0;i<array.Length;i++)
                        {
                            copyarray[i] = array[i];
                        }
                        Console.WriteLine("Array is Copied:");
                        for (int i=0;i<array.Length;i++)
                        {
                            Console.WriteLine(copyarray[i]);
                        }
                        break;

                    case 12://unique elements
                        Console.WriteLine("Unique Numbers in the Array are:");
                        for (int i=0;i<array.Length;i++)
                        {
                            bool unique=true;
                            for (int j=0;j<array.Length; j++)
                            {
                                if (array[i]==array[j] && i!=j)
                                {
                                    unique = false;
                                    break;
                                }
                            }
                            if (unique)
                            {
                                Console.WriteLine($"{array[i]}");
                            }
                        }
                        break;
                    case 13://most repeated number
                        int mostrepeatednumber = -1;
                        int maxcount = 0;

                        for(int i=0;i<array.Length;i++)
                        {
                            int count = 0;
                            for (int j=0;j<array.Length;j++)
                            {
                                if (array[i]==array[j])
                                {
                                    count++;
                                }
                            }
                            if (count>maxcount)
                            {
                                maxcount = count;
                                mostrepeatednumber = array[i];
                            }
                        }
                        if (maxcount>1)
                        {
                            Console.WriteLine($"Most repeated number:{mostrepeatednumber}");
                            Console.WriteLine($"It's number of Counts:{maxcount}");
                        }
                        break;

                    case 14: //count of duplicate entries
                            int duplicatecount = 0;
                        for (int i=0;i<array.Length;i++)
                        {
                            bool isduplicate = false;
                            for (int j=0;j<i; j++)
                            {
                                if (array[i]==array[j])
                                {
                                    isduplicate = true;
                                    break;
                                }
                            }

                            if (!isduplicate)
                            {
                                for (int k=1+i;k<array.Length;k++)
                                {
                                    if (array[i]==array[k])
                                    {
                                        duplicatecount++;
                                    }
                                }
                            }

                        }
                        Console.WriteLine($"Count of duplicate Entries:{duplicatecount}");
                        break;

                    case 0://exit
                        return;

                }

            }
            Console.ReadKey();
        }
    }
}
