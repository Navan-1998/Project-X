﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment21
{
    class Program
    {
        static void Main(string[] args)
        {
            int vals;
            Console.WriteLine("Enter the Number of Values");
            vals = Convert.ToInt32(Console.ReadLine());
            int abssum = 0;
            for (int i=0;i<vals;i++)
            {
                Console.WriteLine($"Enter the value {i + 1}");
                int num = Convert.ToInt32(Console.ReadLine());
                int absval = num < 0 ? -num : num;
                abssum = abssum + absval;
            }
            Console.WriteLine($"Absolute sum is{abssum}");
            Console.ReadKey();
        }
    }
}
