﻿//12. Write a program to swap first and last digit of a number
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment12
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            Console.WriteLine("Enter the Number:");
            number = Convert.ToInt32(Console.ReadLine());
            string numberstring = number.ToString();
            char[] charArray = numberstring.ToCharArray();
            char temp = charArray[0];
            charArray[0] = charArray[charArray.Length - 1];
            charArray[charArray.Length - 1] = temp;
            String swappednumberstr = new string(charArray);
            Console.WriteLine($"Number after swapping={swappednumberstr}");
            Console.ReadKey();
        }
    }
}
