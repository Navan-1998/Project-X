﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment23
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Enter No of Rows:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Enter No of Columns:");
            int b = Convert.ToInt32(Console.ReadLine());

            int[,] matrixA = new int[a, b];
            int[,] matrixB = new int[a, b];

            Console.WriteLine("Enter the elements to MatrixA:");
            for (int i=0;i<a;i++)
            {
                for (int j=0;j<b;j++)
                {
                    matrixA[i,j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.Write("Enter Elements to the MatrixB");
            for (int i=0;i<a;i++)
            {
                for (int j=0;j<b;j++)
                {
                    matrixB[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            //bool operation = true;
            while (true)
            {
                Console.WriteLine("Matrics Operations");
                Console.WriteLine("1.Addition");
                Console.WriteLine("2.Substraction");
                Console.WriteLine("3.Transpose of a Matrix A");
                Console.WriteLine("4.Check Matrices A is Symmetric or Not");
                Console.WriteLine("5.Check Matrices B is Symmetric or Not");
                Console.WriteLine("6.left diagonal sum of Matrix A");
                Console.WriteLine("7.left diagonal sum of Matrix B");
                Console.WriteLine("8.Lower of triangle of Matrix A");
                Console.WriteLine("9.Lower of triangle of Matrix B");
                Console.WriteLine("10.Upper of triangle of Matrix A");
                Console.WriteLine("11.Upper of triangle of Matrix B");
                Console.WriteLine("12.Check if Matrix A is sparce Matrix");
                Console.WriteLine("13.Check if Matrix B is sparce Matrix");
                Console.WriteLine("14.Matrices are equal or not");
                Console.WriteLine("15.Exit");

                Console.WriteLine("Select an Option");

                string ch = Console.ReadLine();
                switch (ch)
                {
                    case "1"://Addition
                        int[,] result = new int[a, b];
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                result[i, j] = matrixA[i, j] + matrixB[i, j];
                                Console.WriteLine(result[i, j]);
                            }
                        }
                        break;

                    case "2"://Substraction
                        int[,] sub_matrix = new int[a, b];
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                sub_matrix[i,j] = matrixA[i,j] - matrixB[i,j];
                                Console.WriteLine(sub_matrix[i, j]);
                            }
                        }
                        break;

                    case "3"://transpose of MatrixA and MatrixB

                        int[,] trans_matrix = new int[a, b];
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                trans_matrix[i, j]=matrixA[j,i];
                                Console.WriteLine(trans_matrix[i, j]);
                            }
                        }
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                trans_matrix[i, j] = matrixB[j, i];
                                Console.WriteLine(trans_matrix[i, j]);
                            }
                        }
                        break;

                    case "4"://symmetric of a
                        if (a != b)
                        {
                            Console.WriteLine("Not Possible !");
                        }
                        int aflag = 0;
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                if (matrixA[i, j] != matrixA[j, i]) ;
                                {
                                    aflag = 1;
                                }
                            }
                        }
                        if (aflag == 1)
                        {
                            Console.WriteLine("Not Symmetric");
                        }
                        else
                        {
                            Console.WriteLine(" is Symmetric");
                        }
                        break;

                    case "5"://symmetric of b
                        if (a != b)
                        {
                            Console.WriteLine("Not Possible !");
                        }
                        int bflag = 0;
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                if (matrixB[i, j] != matrixB[j, i]) ;
                                {
                                    aflag = 1;
                                }
                            }
                        }
                        if (bflag == 1)
                        {
                            Console.WriteLine("Not Symmetric");
                        }
                        else
                        {
                            Console.WriteLine(" is Symmetric");
                        }
                        break;

                    case "6"://left diagonal of A
                        int leftdiasumA = 0;
                        for (int i = 0; i < a; i++)
                        {
                            leftdiasumA = leftdiasumA + matrixA[i, i];
                        }
                        Console.WriteLine($"Sum of left diagonal is: {leftdiasumA} ");
                        break;

                    case "7"://left diagonal of B
                        int leftdiasumB = 0;
                        for (int i = 0; i < a; i++)
                        {
                            leftdiasumB = leftdiasumB + matrixB[i,i];
                        }
                        Console.WriteLine($"Sum of left diagonal is: {leftdiasumB} ");
                        break;

                    case "8"://lower triangle of Matrix A
                        int[,] lowTriA = new int[a, b];
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j <= i; j++)
                            {
                                lowTriA[i, j] = matrixA[i, j];
                                Console.WriteLine(lowTriA[i,j]);
                            }
                        }
                        break;
                    case "9"://lower triangle of B
                        int[,] lowTriB = new int[a, b];
                        for (int i= 0; i < a;i++)
                        {
                            for (int j=0;j<=i;j++)
                            {
                                lowTriB[i, j] = matrixB[i, j];
                                Console.WriteLine(matrixB[i, j]);
                            }
                        }
                        break;
                    case "10"://upper triangle of A
                        int[,] upperTriA = new int[a, b];
                        for (int i=0;i<a;i++)
                        {
                            for (int j=0;j<b;j++)
                            {
                                upperTriA[i, j] = matrixA[i, j];
                                Console.WriteLine(upperTriA);
                            }
                        }
                        break;
                    case "11"://upper triange of Matrix B
                        int[,] upTriB = new int[a, b];
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = i; j < b; j++)
                            {
                                upTriB[i, j] = matrixB[i, j];
                                Console.WriteLine(upTriB[i,j]);
                            }
                        }
                        break;

                    case "12"://sparse matrix
                        int totalelemetns = a * b;
                        int zerocounts = 0;
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                if (matrixA[i, j] == 0)
                                {
                                    zerocounts++;
                                }
                            }
                        }
                        if (zerocounts > totalelemetns / 2)
                        {
                            Console.WriteLine("It's a Sparse Matrix");
                        }
                        else
                        {
                            Console.WriteLine("It's not a Sparse Matrix");
                        }
                        break;
                    case "14"://Matrix are equal or Not
                        bool equal = true;
                        for (int i = 0; i < a; i++)
                        {
                            for (int j = 0; j < b; j++)
                            {
                                if (matrixA != matrixB)
                                {
                                    equal = false;
                                }

                            }
                        }
                        if (equal = true)
                        {
                            Console.WriteLine("Matrixes are EQUAL");
                        }
                        else
                        {
                            Console.WriteLine("Matrices are NOT EQUAL");
                        }
                        break;

                    case "15":

                        break;
                }
            }



            Console.ReadKey();

        }
    }
}
