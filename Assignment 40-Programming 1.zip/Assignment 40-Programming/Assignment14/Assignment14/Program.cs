﻿//14. Write a program to convert the decimal number to binary,
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment14
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a decimal number");
            num = Convert.ToInt32(Console.ReadLine());
            int[] b = new int[100];
            int i = 0;
            while (num != 0)
            {

                b[i] = num % 2;
                i = i + 1;
                num = num / 2;


            }
            StringBuilder number = new StringBuilder();

            for (int j = i - 1; j >= 0; j--)
            {
                number.Append(b[j]);
            }

            Console.WriteLine($"binary : {number.ToString()}");
            Console.ReadKey();

        }
    }
}
