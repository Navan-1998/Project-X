﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment27
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the string ");
            string str = Console.ReadLine();
            Console.WriteLine("Enter the substring ");
            string str1 = Console.ReadLine();
            int flag = -1;

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == str1[0])
                {
                    if ((i + str1.Length) <= str.Length)
                    {
                        flag = 1;
                    }
                    else
                    {
                        break;
                    }

                    for (int j = 1; j < str1.Length; j++)
                    {
                        if (str[i + j] != str1[j])
                        {
                            flag = 0;
                            break;
                        }
                    }


                }

                if (flag == 1)
                {
                    break;
                }
            }

            if (flag == 1)
            {
                Console.Write("substring is found in the string");
            }
            else
            {
                Console.WriteLine("substring not found");
            }

            Console.ReadKey();
        }
    }
}
