﻿//30. Write a program to create a new array from a given array of strings using all the strings whose length 
//are matched with given string length
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment30
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] resultArray = new string[100];
            Console.WriteLine("Enter the number of Elements in Array:");
            int number = Convert.ToInt32(Console.ReadLine());
            string[] givenArray = new string[100];
            Console.WriteLine("Enter strings to the Array");
            for (int i=0;i<number;i++)
            {
                givenArray[i] = Console.ReadLine();
            }
            string givenString;
            Console.WriteLine("Enter the String");
            givenString = Console.ReadLine();
            int givenStringLength = givenString.Length;
            int k = 0;
            for (int i=0;i<number;i++)
            {
                if (givenArray[i].Length==givenStringLength)
                {
                    resultArray[i]= givenArray[i];
                    k = k + 1;
                }
            }

            for (int i = 0; i < k + 1; i++) 
            {
                Console.WriteLine(resultArray[i]);
            }
            Console.ReadKey();
        }
    }
}
