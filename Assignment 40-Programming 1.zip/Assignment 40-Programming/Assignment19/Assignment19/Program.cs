﻿//Write a program i to display the n terms of harmonic series and their sum [1 + 1/2 + 1/3 + 1/4 + 1/5 
//... 1 / n terms]
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment19
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter the Number of terms in Harmonic Series:");
            n = Convert.ToInt32(Console.ReadLine());
            double sum = 0.0;
             for (int i=1;i<=n;i++)
            {
                double num = 1.0 / i;
                Console.Write($"'{num}' ");
                sum = sum + num;
            }
            Console.WriteLine($"Sum of the series is:{sum}");
            Console.ReadKey();        }
    }
}
