﻿//5.Write a program to swap two numbers without using temporary variable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter a number:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter another number:");
            b = Convert.ToInt32(Console.ReadLine());
            (a, b) = (b, a);
            Console.WriteLine($"First Value after swaping is:{a}");
            Console.WriteLine($"Second Value after saping is:{b}");
            Console.ReadKey();
        }
    }
}
