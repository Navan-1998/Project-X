﻿//18. Write a program to make such a pattern like a pyramid with numbers increased by 1.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment18
{
    class Program
    {
        static void Main(string[] args)
        {
            int numlevels;
            Console.WriteLine("Enter number of levels:");
            numlevels = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Number Pyramid Pattern:");
            for (int i = 1; i <= numlevels; i++)
            {
                for (int j=i;j<=numlevels;j++)
                {
                    Console.Write(" ");
                }
                for (int k=1;k<=i;k++)
                {
                    Console.Write(k + " ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
