﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment34_HexCode
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Enter the code;");
            string inputCode = Console.ReadLine();
            Hex h = new Hex();
            h.checkInput(inputCode);
        }
    }
    public class Hex
    {
        public void checkInput(string inputCode)
        {
            if (string.IsNullOrEmpty(inputCode) || inputCode.Length != 6 || inputCode[0] != '#') ;
            {
                Console.WriteLine($"{inputCode} is NOT Hexcode");
            }
        }
    }
}
