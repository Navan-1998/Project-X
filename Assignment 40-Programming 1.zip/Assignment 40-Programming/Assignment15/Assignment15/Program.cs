﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment15
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a binary Number");
            string binaryvalue = Console.ReadLine();

         int dec = 0;
            int j = 0;

            for (int i = binaryvalue.Length - 1; i >= 0; i--)
            {
                int bit = Convert.ToInt32(binaryvalue[i].ToString());
                dec = dec + Convert.ToInt32(Math.Pow(2, j) * bit);
            }
            Console.WriteLine($"The Decimal Value is:{dec}");
            Console.ReadKey();
        }
  
    }
}
