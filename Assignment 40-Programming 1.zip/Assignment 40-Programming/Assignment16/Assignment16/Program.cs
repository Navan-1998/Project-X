﻿//16. Write a program to print the Fibonacci series
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment16
{
    class Program
    {
        static void Main(string[] args)
        {
            int nterms;
            Console.WriteLine("How many terms?");
            nterms = Convert.ToInt32(Console.ReadLine());
            int n1 = 0;
            int n2 = 1;
            if (nterms <= 0)
            {
                Console.WriteLine("Enter a positive number");
            }
            else if (nterms == 1) 
            {
                Console.WriteLine($"Fibonacci series upto {nterms} :{n1}");
            }
            else
            {
                Console.WriteLine($"Fibonncai series is:");
                for (int i = 0;i < nterms; i++)
                {
                    Console.WriteLine($"{n1}");
                    int nth = n1 + n2;
                    n1 = n2;
                    n2 = nth;

                }
            } 
            Console.ReadKey();
        }
    }
}
