﻿//11. Write a program to print the factorial of a number
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment11
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Enter A Number:");
            a = Convert.ToInt32(Console.ReadLine());
            int factorial = 1;
            if (a < 0)
            {
                Console.WriteLine("Factorial does not exist for negative numbers");
            }
            else if (a == 0)
            {
                Console.WriteLine($"Factorial of {a} is 1");
            }
            else
            {
                for (int i=1;i<=a; i++)
                {
                    factorial = factorial * i;
                    
                }
                Console.WriteLine($"Factorial of the number {a} is {factorial}");
            }
            Console.ReadKey();
        }
    }
}
