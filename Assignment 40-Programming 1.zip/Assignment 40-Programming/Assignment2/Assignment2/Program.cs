﻿//2. Write a program in C# for calculate the surface and volume of a sphere, given its radius.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            int radius;
            Console.WriteLine("Enter the radius of sphere:");
            radius = Convert.ToInt32(Console.ReadLine());
            double sa = 4 * (3.14) * (radius * radius);
            double vol = (4 / 3) * (3.14) * (radius * radius * radius);
            Console.WriteLine($"Surface area of the sphere is:{sa}");
            Console.WriteLine($"The volume of the sphere is:{vol}");
            Console.ReadKey();
        }
    }
}