﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment25
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number of Elements:");
            int number = Convert.ToInt32(Console.ReadLine());

            int[] numArray = new int[number];
            for (int i=0;i<number;i++)
            {
                Console.WriteLine($"Enter {i + 1} elements");
                numArray[i] = Convert.ToInt32(Console.ReadLine());
            }

            StringBuilder s1 = new StringBuilder();
            StringBuilder s2 = new StringBuilder();

            s1.Append(numArray[0]);
            for (int i =1; i < number; i++)     
            {
                if (numArray[i]>numArray[i-1])
                {
                    s1.Append(" " + numArray[i]);
                }
                else
                {
                    if (s1.Length>s2.Length)
                    {
                        s2.Clear();
                        s2.Append(s1);
                        s1.Clear();
                        s1.Append(numArray[i]);
                    }
                }
            }
            Console.WriteLine(s2);
            Console.ReadKey();
        }
    }
}
