﻿//17.Write a program to find Armstrong numbers between 1 to n
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment17
{
    class Program
    {
        static void Main(string[] args)
        {
            int lower = 1;
            int n;
            Console.WriteLine("Enter the upper limit:");
            n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Armstrong number between 1 and {n} are:");
            for (int num=1; num<=n ; num++)
            {
                string numStr = num.ToString();
                int numberofdigits = numStr.Length;
                int sum = 0;
                int temp = num;
                while (temp>0)
                {
                    int digit = temp % 10;
                    sum = sum + (int)Math.Pow(digit, numberofdigits);
                    temp /= 10;
                }
                if (sum==num)
                {
                    Console.WriteLine(num);
                }
            }
            Console.ReadKey();

        }
    }
}
