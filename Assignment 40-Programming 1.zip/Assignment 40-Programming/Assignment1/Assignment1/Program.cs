﻿//1. Write a program in C# to perform basic operations of calculator
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter a Number:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter another number:");
            b = Convert.ToInt32(Console.ReadLine());
            int sum = a + b;
            Console.WriteLine($"Sum of numbers is:{sum}");
            int sub = a - b;
            Console.WriteLine($"Substraction of the numbers is:{sub}");
            int mutlti = a * b;
            Console.WriteLine($"Multiplication result is:{mutlti}");
            float div = a / b;
            Console.WriteLine($"Division result is:{div}");
            float mod = a % b;
            Console.WriteLine($"Reminder is:{mod}");
            Console.ReadKey();

        }
    }
}
