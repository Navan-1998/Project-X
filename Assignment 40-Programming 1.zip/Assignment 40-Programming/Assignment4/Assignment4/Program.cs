﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter number of days:");
            num = Convert.ToInt32(Console.ReadLine());
            int year = num / 365;
            int rem = (num % 365);
            int week = rem  / 7;
            int days = rem % 7;
            Console.WriteLine($"{num} of days is:-{year} Years, {week} Weeks, {days} Days.");
            Console.ReadKey();

        }
    }
}
