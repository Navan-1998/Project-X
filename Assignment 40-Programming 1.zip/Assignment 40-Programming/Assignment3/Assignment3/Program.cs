﻿//3. Write a program that requests the width (x) and height (y) of a rectangle and calculate the perimeter, area and diagonal.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            Console.WriteLine("Enter the width(x): ");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the height(y)");
            y = Convert.ToInt32(Console.ReadLine());
            int perimeter = 2*(x + y);
            int area = x * y;
            double diagonal = Math.Sqrt((x * x) + (y * y));
            Console.WriteLine($"Perimeter of the Rectangle is: {perimeter}");
            Console.WriteLine($"area of the rectangle is: {area}");
            Console.WriteLine($"diagonal of the rectangle is: {diagonal}");
            Console.ReadKey();
        }
    }
}
