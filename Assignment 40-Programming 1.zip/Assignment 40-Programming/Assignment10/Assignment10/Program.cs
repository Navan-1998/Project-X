﻿//10.Write a program to print the difference between the largest and smallest number among three numbers
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment10
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            Console.WriteLine("Enter three numbers:");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());
            int largest = a;
            int smallest = a;
            if (b>largest)
            {
                largest = b;
            }
            if (b<smallest)
            {
                smallest = b;
            }
            if (c>largest)
            {
                largest = c;
            }
            if (c < smallest)
            {
                smallest = c;
            }
            int diff = (largest - smallest);
            Console.WriteLine($"Difference between largest and smallest Number is:{diff}");
            Console.ReadKey();
        }
    }
}
