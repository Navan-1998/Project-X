﻿//6.Write a program to print the multiplication table of any user input data.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Multiplication table of:");
            a = Convert.ToInt32(Console.ReadLine());
            for (int i=1; i < 11; i++)
            {
                Console.WriteLine($"{a}*{i}={a * i}");
            }
            Console.ReadKey();
        }
    }
}
