﻿//8. Write a program to check a number is prime or not
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Enter a number:");
            a=Convert.ToInt32(Console.ReadLine());
            bool prime = false;
            if (a <= 1)
            {
                Console.WriteLine($"{a} is not a prime number");
            }
            else
            {
                for (int i=2;i<=a;i++)
                {
                    if (a % i==0)
                    {
                        prime = false;
                        break;
                    }
                }
            }
            if (prime)
            {
                Console.WriteLine($"{a} is PRIME");
            }
            else
            {
                Console.WriteLine($"{a} is not PRIME");
            }
            Console.ReadKey();
        }
    }
}

