﻿//9. Write a program to check the given year is leap or not
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment9
{
    class Program
    {
        static void Main(string[] args)
        {
            int year;
            Console.WriteLine("Enter an Year:");
            year = Convert.ToInt32(Console.ReadLine());
            if ((year % 400 == 0) && (year % 100 == 0))
                {
                Console.WriteLine($"{year} is a Leap Year");
            }
            else if ((year%4==0) && (year%100!=0))
                {
                Console.WriteLine($"{year} is a Leap Year");
            }
            else
            {
                Console.Write($"{year} is not Leap Year");
            }
            Console.ReadKey();
        }
    }
}
