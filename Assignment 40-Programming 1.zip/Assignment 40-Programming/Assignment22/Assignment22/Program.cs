﻿//22. Write a program to multiply corresponding elements of two arrays of integers.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment22
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = { 1, 2, 3, 4, 5 };
            int[] array2 = { 6, 7, 8, 9, 10 };
            int[] resultarray = new int[array1.Length];
            for (int i=0;i<array1.Length;i++)
            {
                resultarray[i] = array1[i] * array2[i];
            }
            for (int i=0;i<array1.Length;i++)
            {
                Console.WriteLine($"{resultarray[i]}");
            }
            Console.ReadKey();
        }
    }
}
