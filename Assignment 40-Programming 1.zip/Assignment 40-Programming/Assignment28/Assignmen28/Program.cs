﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignmen28
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string");
            string word = Console.ReadLine();

            int alphabetcount = 0;
            int digitcount = 0;
            int charcount = 0;

            for (int i=0;i<word.Length;i++)
            {
                char ch = word[i];

                if (char.IsLetter(ch))
                {
                    alphabetcount++;
                }    
                else if (char.IsDigit(ch))
                {
                    digitcount++;
                }
                else
                {
                    charcount++;
                }
                
            }
            Console.WriteLine($"Total Number of Alphabets:{alphabetcount}");
            Console.WriteLine($"Total Number of Digits:{digitcount}");
            Console.WriteLine($"Total Number of Characters:{charcount}");
            Console.ReadKey();
        }
    }
}
