﻿//7. Write a program to count total number of notes in entered amount.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.WriteLine("Enter the Amount:");
            a = Convert.ToInt32(Console.ReadLine());
            int twothousand = a / 2000;
            int rem1 = a % 2000;
            int fivehundres = rem1 / 500;
            int rem2 = rem1 % 500;
            int twohundred = rem2 / 200;
            int rem3 = rem2 % 200;
            int onehundres = rem3 / 100;
            int rem4 = rem3 % 100;
            int fifty = rem4 / 50;
            int rem5 = rem4 % 50;
            int twenty = rem5 / 20;
            int rem6 = rem5 % 20;
            int ten = rem6 / 10;
            Console.WriteLine($"The Amount {a} contains:-\n {twothousand} number of 2000 notes\n{fivehundres} number of 500 notes\n {twohundred} number of 200 notes\n {onehundres} notes of 100\n {fifty} notes of 50\n {twenty} notes of 20\n {ten} notes of 10");
            Console.ReadKey();
        }
    }
}
