﻿//29. Write a program to read a sentence and replace lowercase characters by uppercase and vice-versa
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment29
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter A input");
            string input = Console.ReadLine();
            char[] array = input.ToCharArray();

            for (int i=0;i<array.Length;i++)
            {
                if (char.IsUpper(array[i]))
                {
                    array[i] = char.ToLower(array[i]);
                }
                else if (char.IsLower(array[i]))
                {
                    array[i]=char.ToUpper(array[i]);
                }
            }
            string output = new string(array);
            Console.WriteLine($"Output is: {output}");
            Console.ReadKey();

        }
    }
}
