﻿//26. Write a program to check a string is palindrome or not.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment26
{
    class Program
    {
        static void Main(string[] args)
        {
            string word;
            Console.WriteLine("Enter a word");
            word = Console.ReadLine();
            StringBuilder reversestr = new StringBuilder();
            int strlength = word.Length;
            for (int i=(strlength-1);i>=0;i--)
            {
                reversestr.Append(word[i]);
            }
            if (word.Equals(reversestr.ToString()))
            {
                Console.WriteLine($"{word} is pallindrome");
            }
            else
            {
                Console.WriteLine($"{word} is not pallindrome");
            }
            Console.ReadKey();
        }
    }
}
