﻿//24. Write a program which will accept a list of integers and checks how many integers are needed to 
//complete the range.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment24
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter the number of elements in the array: ");
            int n = int.Parse(Console.ReadLine());

            int[] arr = new int[n];
            int number = 0;

            Console.WriteLine("Enter the Integers to the array:");
            for (int i = 0; i < n; i++)
            {

                arr[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {

                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }

            for (int i = 0; i < n - 1; i++)
            {
                for (int j = arr[i] + 1; j < arr[i + 1]; j++)
                {
                    number++;
                }

            }

            Console.WriteLine("number of integers needed are " + number);


            Console.ReadKey();

        }
    }
}
